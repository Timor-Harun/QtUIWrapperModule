#pragma once

#ifndef wrapped_H
#define wrapped_H
#include "qtuiwrappermodule_global.h"

#include <QWidget>
#include <QPushButton>
#include <QLineEdit>
#include <QLabel>
#include <QComboBox>
#include <QGroupBox>
#include <QCheckBox>
#include <QTabWidget>
#include <QTableWidget>
#include "IPAddress.h"
#include <QMessageBox>
#include <QFileDialog>
#include <QLayout>
#include <QProgressBar>
#include <Qplaintextedit>
#include <QMenuBar>
#include <boost/python.hpp>
#include <python.h>

#include "MyProgressBar.h"
using namespace std;
using namespace boost::python;

typedef  void(QWidget::* PFN_resize)(int, int);
typedef  void(QComboBox::* PFN_addItem)(const QString&,const QVariant&);
typedef  void(QLayout::* PFN_setContentMargins)(int, int, int, int);

class QtUtility
{
public:
	static void MessageBoxInfo(const QString &title, const QString &message)
	{
		QMessageBox::information(NULL, title, message);
	}
	static void MessageBoxError(const QString& title, const QString& message)
	{
		QMessageBox::warning(NULL, title, message);
	}
	static void MessageBoxWarning(const QString& title, const QString& message)
	{
		QMessageBox::critical(NULL, title, message);
	}

	static std::string GetOpenFilePath(QString title,QString filter,QString defaultPath = QString())
	{
		return QFileDialog::getOpenFileName(NULL, title, defaultPath, filter).toStdString();
	}

	static std::string GetSaveFilePath(QString title, QString filter,QString defaultPath = QString())
	{
		return QFileDialog::getSaveFileName(NULL, title, defaultPath, filter).toStdString();
	}
};
BOOST_PYTHON_MODULE(qt_module_wrapped)
{
	class_<QWidget, boost::noncopyable>("qwidget_class", boost::python::no_init)
		.def("setSize", (PFN_resize)&QWidget::resize)
		.def("show", &QWidget::show)
		.def("close", &QWidget::close)
		.def("setHidden", &QWidget::setHidden)
		.def("setQss",&QWidget::setStyleSheet);

	class_<QLabel, boost::noncopyable>("qlabel_class", boost::python::no_init)
		.def("setText", &QLabel::setText)
		.def("getText", &QLabel::text)
		.def("setSize", (PFN_resize)&QLabel::resize)
		.def("setEnabled",&QLabel::setEnabled)
		.def("setHidden", &QLabel::setHidden)
		.def("setQss", &QLabel::setStyleSheet)
		.def("setPicture",&QLabel::setPixmap);

	class_<QPushButton, boost::noncopyable>("qbutton_class", boost::python::no_init)
		.def("setSize", (PFN_resize)&QPushButton::resize)
		.def("setEnabled", &QPushButton::setEnabled)
		.def("setHidden", &QPushButton::setHidden)
		.def("setQss", &QPushButton::setStyleSheet);

	class_<QLineEdit, boost::noncopyable>("qedit_class", boost::python::no_init)
		.def("setText", &QLineEdit::setText)
		.def("getText", &QLineEdit::text)
		.def("setSize", (PFN_resize)&QLineEdit::resize)
		.def("setEnabled", &QLineEdit::setEnabled)
		.def("setHidden", &QLineEdit::setHidden)
		.def("setQss", &QLineEdit::setStyleSheet);

	class_<QCheckBox, boost::noncopyable>("qcheckbox_class", boost::python::no_init)
		.def("getChecked",&QCheckBox::isChecked)
		.def("setChecked", &QCheckBox::setChecked)
		.def("setSize", (PFN_resize)&QCheckBox::resize)
		.def("setEnabled", &QCheckBox::setEnabled)
		.def("setHidden", &QCheckBox::setHidden)
		.def("setQss", &QCheckBox::setStyleSheet);

	class_<QComboBox, boost::noncopyable>("qcombobox_class", boost::python::no_init)
		.def("addItem", (PFN_addItem)&QComboBox::addItem)
		.def("removeItem", &QComboBox::removeItem)
		.def("getCount",&QComboBox::count)
		.def("getItem",&QComboBox::itemText)
		.def("currentIndex",&QComboBox::currentIndex)
		.def("setSize", (PFN_resize)&QComboBox::resize)
		.def("setEnabled", &QComboBox::setEnabled)
		.def("setHidden", &QComboBox::setHidden)
		.def("setQss", &QComboBox::setStyleSheet);

	class_<IPAddress, boost::noncopyable>("ipaddress_class", boost::python::no_init)
		.def("getIP",&IPAddress::getIP)
		.def("setIP", &IPAddress::setIP)
		.def("setSize", (PFN_resize)&IPAddress::resize)
		.def("setEnabled", &IPAddress::setEnabled)
		.def("setHidden", &IPAddress::setHidden)
		.def("setQss", &IPAddress::setStyleSheet);

	class_<QTabWidget, boost::noncopyable>("qtabwidget_class", boost::python::no_init)
		.def("setSize", (PFN_resize)&QTabWidget::resize)
		.def("setEnabled", &QTabWidget::setEnabled)
		.def("setHidden", &QTabWidget::setHidden)
		.def("setQss", &QTabWidget::setStyleSheet)
		.def("currentIndex", &QTabWidget::currentIndex)
		.def("setIndex", &QTabWidget::setCurrentIndex)
		.def("setTabText", &QTabWidget::setTabText);

	class_<QHBoxLayout, boost::noncopyable>("qhboxlayout_class", boost::python::no_init)
		.def("setContentsMargins", (PFN_setContentMargins)&QHBoxLayout::setContentsMargins)
		.def("setSpacing", &QHBoxLayout::setSpacing);

	class_<QVBoxLayout, boost::noncopyable>("qvboxlayout_class", boost::python::no_init)
		.def("setContentsMargins", (PFN_setContentMargins)&QVBoxLayout::setContentsMargins)
		.def("setSpacing", &QVBoxLayout::setSpacing);

	class_<MyProgressBar, boost::noncopyable>("qprogressbar_class", boost::python::no_init)
		.def("setSize", (PFN_resize)&MyProgressBar::resize)
		.def("setEnabled", &MyProgressBar::setEnabled)
		.def("setHidden", &MyProgressBar::setHidden)
		.def("setRange", &MyProgressBar::setRange)
		.def("setValue", &MyProgressBar::mySetValue)
		.def("getValue", &MyProgressBar::value)
		.def("setQss", &MyProgressBar::setStyleSheet);

	class_<QString>("qstr", init<const char*>()).def("stdstr",&QString::toStdString);

	class_<QPlainTextEdit, boost::noncopyable>("qpalintextedit_class")
		.def("setSize", (PFN_resize)&QPlainTextEdit::resize)
		.def("setEnabled", &QPlainTextEdit::setEnabled)
		.def("setHidden", &QPlainTextEdit::setHidden)
		.def("setText", &QPlainTextEdit::setPlainText)
		.def("getText", &QPlainTextEdit::toPlainText)
		.def("setQss", &QPlainTextEdit::setStyleSheet);

	class_<QtUtility>("qutility_class")
		.def("messageBox", &QtUtility::MessageBoxInfo)
		.def("openFile", &QtUtility::GetOpenFilePath)
		.def("saveFile", &QtUtility::GetSaveFilePath);

	DECLARE_SHARED_PTR(QWidget);
	DECLARE_SHARED_PTR(QLabel);
	DECLARE_SHARED_PTR(QPushButton);
	DECLARE_SHARED_PTR(QLineEdit);
	DECLARE_SHARED_PTR(QComboBox);
	DECLARE_SHARED_PTR(QCheckBox);
	DECLARE_SHARED_PTR(IPAddress);
	DECLARE_SHARED_PTR(QHBoxLayout);
	DECLARE_SHARED_PTR(QVBoxLayout);
	DECLARE_SHARED_PTR(QString);
	DECLARE_SHARED_PTR(MyProgressBar);
}
#endif
