#pragma once

#include <QtCore/qglobal.h>

#ifndef BUILD_STATIC
# if defined(QTUIWRAPPERMODULE_LIB)
#  define QTUIWRAPPERMODULE_EXPORT Q_DECL_EXPORT
# else
#  define QTUIWRAPPERMODULE_EXPORT Q_DECL_IMPORT
# endif
#else
# define QTUIWRAPPERMODULE_EXPORT
#endif

#define DECLARE_SHARED_PTR(className) typedef boost::shared_ptr<className> className##PTR;register_ptr_to_python<className##PTR>();