#pragma once
#pragma once
#include <qprogressbar.h>

class MyProgressBar :public QProgressBar
{
	Q_OBJECT

Q_SIGNALS:
	void updateValue_signal(int value);

public:
	MyProgressBar(QWidget* parent = nullptr) :QProgressBar(parent)
	{

	}
	~MyProgressBar()
	{

	}
	void mySetValue(int value)
	{
		emit updateValue_signal(value);
	}
};
